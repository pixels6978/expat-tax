<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ForeignAccountsEntitiesController extends Controller
{
    public function show5471()
    {
        return view('foreign_accounts.5471');
    }

    public function show3520()
    {
        return view('foreign_accounts.3520');
    }

    public function showFBR8938()
    {
        return view('foreign_accounts.FBR-8938');
    }
}
