@extends('basetheme')

@section('title', 'Passive Income')

@section('pageheader', 'Passive Income')

@section('content')

<div class="row mt-4 content-port">

	<div class="row mt-4">
         @livewire('income.passive-income')
     </div>
</div>


@endsection





