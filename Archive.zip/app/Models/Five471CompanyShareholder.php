<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Five471CompanyShareholder extends Model
{
    use HasFactory;

    protected $table = '5471_company_shareholders';
}
