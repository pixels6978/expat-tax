<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SaleOfProperty extends Model
{
    use HasFactory;

    protected $table = 'rentalincome_sale_of_property';
}
