<?php
namespace App\Http\Livewire\Income;

use Livewire\Component;

class ForeignErnedIncome extends Component
{
    public function render()
    {
        return view('livewire.foreign-erned-income');
    }
}
