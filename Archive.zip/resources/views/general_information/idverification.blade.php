@extends('basetheme')

@section('title', 'Id Verification')

@section('pageheader', 'Id Verification')

@section('content')
 
<div class="row mt-4 content-port">   
                                                                                                                      
  @livewire('generalinfo.id-verification')   


</div>                                                       
                                                    
                                                 
@endsection