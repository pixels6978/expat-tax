<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FiveFour71CompanyInformation extends Model
{
    use HasFactory;

    protected $table = '5471_company_information';
}
