@extends('basetheme')

@section('title', 'Persoanl Information')

@section('pageheader', 'Personal Information')

@section('content')
 
<div class="row mt-4 content-port">   
     
     
	<div class="row mt-4">
      
	   @livewire('generalinfo.personal-information')
                                                                                                                      
     </div>                                                      
</div>                                                       
                                                    
                                                 
@endsection